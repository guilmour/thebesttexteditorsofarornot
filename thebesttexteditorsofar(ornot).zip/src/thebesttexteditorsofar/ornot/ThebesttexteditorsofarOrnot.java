
package thebesttexteditorsofar.ornot;
import java.util.*;
import java.awt.Image;
import java.awt.Toolkit;

public class ThebesttexteditorsofarOrnot {


    public static void main(String[] args) {
        
      
      Janela janela = new Janela();
      janela.setLocation(200, 200);
      janela.setIconImage(Toolkit.getDefaultToolkit().getImage("ico.png"));
      janela.setVisible(true);
      
    }
    
}
